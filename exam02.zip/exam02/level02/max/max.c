int     max(int *tab, unsigned int len)
