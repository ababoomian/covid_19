gcc main.c ft_range.c -o test_program
./test_program
