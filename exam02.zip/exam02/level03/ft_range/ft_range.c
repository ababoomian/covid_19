#include <stdlib.h>
#include <stdio.h>

int	*ft_range(int start, int end)
{
	int	size;
	int	*ret;
	int	*ptr;

	size = (end - start) + 1 ;
	if (size >= 0)
	{
		ptr = (int *)malloc(sizeof(int) * size);
		if (ptr >= 0)
		{
			ret = ptr;
			while (start <= end)
			{
				*ptr = start;
				ptr++;
				start++;
			}
			ret = ptr;
			return (ret);
		}
	}
	return (NULL);
}

